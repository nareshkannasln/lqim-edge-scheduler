"""Generate simulation results as JSON for the web dashboard."""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lqim import run_simulation, EdgeSimulator, LQIM, GeneticAlgorithmScheduler, PSOScheduler
import numpy as np

def generate_results():
    summary = run_simulation(n_tasks=50, n_nodes=10, seed=42)

    # Task-by-task time series
    series = {}
    for method in ["LQIM", "GA", "PSO"]:
        series[method] = {
            "latency": [round(r.latency_ms, 2) for r in summary[method]["results"]],
            "energy": [round(r.energy_j, 4) for r in summary[method]["results"]],
            "utilization": [round(r.utilization * 100, 2) for r in summary[method]["results"]],
            "solve_time": [round(r.solve_time_ms, 3) for r in summary[method]["results"]],
        }

    # Bar chart summary
    bar = {}
    for method in ["LQIM", "GA", "PSO"]:
        bar[method] = {
            "avg_latency": summary[method]["avg_latency_ms"],
            "avg_energy": summary[method]["avg_energy_j"],
            "avg_utilization": round(summary[method]["avg_utilization"] * 100, 2),
            "avg_solve_time": summary[method]["avg_solve_time_ms"],
        }

    ga_lat = summary["GA"]["avg_latency_ms"]
    lqim_lat = summary["LQIM"]["avg_latency_ms"]
    ga_eng = summary["GA"]["avg_energy_j"]
    lqim_eng = summary["LQIM"]["avg_energy_j"]
    ga_util = summary["GA"]["avg_utilization"]
    lqim_util = summary["LQIM"]["avg_utilization"]
    pso_lat = summary["PSO"]["avg_latency_ms"]
    pso_eng = summary["PSO"]["avg_energy_j"]

    improvements = {
        "latency_vs_ga": round((ga_lat - lqim_lat) / ga_lat * 100, 1),
        "latency_vs_pso": round((pso_lat - lqim_lat) / pso_lat * 100, 1),
        "energy_vs_ga": round((ga_eng - lqim_eng) / ga_eng * 100, 1),
        "energy_vs_pso": round((pso_eng - lqim_eng) / pso_eng * 100, 1),
        "util_vs_ga": round((lqim_util - ga_util) / ga_util * 100, 1),
    }

    # Node state snapshot
    sim = EdgeSimulator(n_nodes=10, seed=42)
    nodes = [{
        "id": n.node_id,
        "cpu_ghz": n.cpu_ghz,
        "ram_gb": n.ram_gb,
        "load": round(n.current_load * 100, 1),
        "energy_budget": n.energy_budget,
    } for n in sim.nodes]

    output = {
        "summary": bar,
        "series": series,
        "improvements": improvements,
        "nodes": nodes,
        "n_tasks": 50,
        "n_nodes": 10,
    }
    return output

if __name__ == "__main__":
    data = generate_results()
    print(json.dumps(data))
